import React from 'react'

const Public = () => {

  return (
    <h1>You must log in first...</h1>
  )
}

export default Public